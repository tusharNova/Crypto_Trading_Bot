from binance import Client
from binance.exceptions import BinanceAPIException
import config
from logger import setup_logger
import test_connection


class BasicBot:
    def __init__(self , api_key = None , api_secret = None , testnet = True):

        self.api_key = api_key or config.API_Key
        self.api_secret = api_secret or config.API_Secret

        self.testnet = testnet
        self.logger = setup_logger()

        try:
            self.client = Client(self.api_key, self.api_secret, testnet=self.testnet)
            self.logger.info("Bot initialized successfully")
            self._test_connection()
        except Exception as e:
            self.logger.error(f"Failed to initialize bot: {str(e)}")

    def _test_connection(self):
        try:
            account = self.client.futures_account()
            self.logger.info("API connection successful")
            return True
        except Exception as e:
            self.logger.error(f"API connection failed: {str(e)}")
            return False

    def get_account_balance(self):
        try:
            balance = self.client.futures_account_balance()
            self.logger.info("Retrieved account  balance")
            return balance

        except BinanceAPIException as e:
            self.logger.error(f"Failed to get balance: {str(e)}")
            return None

    def get_symbol_price(self, symbol):
        """get price for symbol"""
        try:
            ticker = self.client.futures_symbol_ticker(symbol=symbol)
            price = float(ticker['price'])
            self.logger.info(f"Price for {symbol}: {price}")
            return price
        except BinanceAPIException as e:
            self.logger.error(f"Failed to get price for {symbol}: {str(e)}")
            return None

    def place_market_order(self , symbol , side , quantity):
        try :
            self.logger.info(f"Placing {side} market order: {quantity} {symbol}")
            if not self._validate_order_inputs(symbol, side, quantity):
                return None

            order = self.client.futures_create_order(
                symbol=symbol,
                side=side,
                type='MARKET',
                quantity=quantity
            )
            self.logger.info(f"Market order placed successfully: {order['orderId']}")
            return order

        except Exception as e:
            self.logger.error(f"Order Failed: {str(e)}")
            return False

    def place_limit_order(self, symbol, side, quantity, price):
        try :
            self.logger.info(f"Placing {side} limit order: {quantity} {symbol} at {price}")

            if not self._validate_order_inputs(symbol, side, quantity, price):
                return None

            order = self.client.futures_create_order(
                symbol=symbol,
                side=side,
                type='LIMIT',
                timeInForce='GTC',  # Good Till Cancelled
                quantity=quantity,
                price=price
            )

            self.logger.info(f"Limit order placed successfully: {order['orderId']}")
            return order

        except Exception as e:
            self.logger.error(f"place limit Order Failed: {str(e)}")
            return False

    def _validate_order_inputs(self , symbol , side , quantity , price=None):
        if not symbol or len(symbol) < 3:
            self.logger.error("Invalid symbol")
            return False
        if side not in ['BUY' , 'SELL']:
            self.logger.error("Side must be 'BUY' or 'SELL'")
            return False

        try:
            quantity = float(quantity)
            if quantity <= 0:
                self.logger.error("Quantity must be positive")
                return False
        except ValueError:
            self.logger.error("Invalid quantity format")
            return False
        if price is not None:
            try:
                price = float(price)
                if price <= 0:
                    self.logger.error("Price must be positive")
                    return False

            except ValueError:
                self.logger.error("Invalid Price format")
                return False

        return True

    def get_order_status(self , symbol , order_id):
        try:
            order = self.client.futures_get_order(symbol=symbol, orderId=order_id)
            self.logger.info(f"Order {order_id} status: {order['status']}")
            return order
        except BinanceAPIException as e:
            self.logger.error(f"Failed to get order status: {str(e)}")
            return None

    def place_stop_limit_order(self, symbol, side, quantity, stop_price, limit_price):
        """Place a stop-limit order"""
        try:
            self.logger.info(
                f"Placing {side} stop-limit order: {quantity} {symbol} stop: {stop_price} limit: {limit_price}")

            # Validate inputs
            if not self._validate_order_inputs(symbol, side, quantity, limit_price):
                return None

            # Validate stop price
            try:
                stop_price = float(stop_price)
                if stop_price <= 0:
                    self.logger.error("Stop price must be positive")
                    return False
            except ValueError:
                self.logger.error("Invalid stop price format")
                return False

            # Place the order
            order = self.client.futures_create_order(
                symbol=symbol,
                side=side,
                type='STOP',
                timeInForce='GTC',
                quantity=quantity,
                price=limit_price,
                stopPrice=stop_price
            )

            self.logger.info(f"Stop-limit order placed successfully: {order['orderId']}")
            return order

        except BinanceAPIException as e:
            self.logger.error(f"Failed to place stop-limit order: {str(e)}")
            return None

    def get_portfolio_summary(self):
        """Get simplified portfolio summary"""
        try:
            # Get basic account info that we know works
            balance = self.client.futures_account_balance()

            # Try to get account info, but handle if some fields are missing
            try:
                account = self.client.futures_account()
                self.logger.info(f"Account response keys: {list(account.keys())}")
            except Exception as e:
                self.logger.warning(f"Could not get full account info: {str(e)}")
                account = {}

            # Try to get positions
            try:
                positions = self.client.futures_position_information()
            except Exception as e:
                self.logger.warning(f"Could not get positions: {str(e)}")
                positions = []

            # Build portfolio with safe defaults
            portfolio = {
                'total_wallet_balance': 0,
                'total_unrealized_pnl': 0,
                'available_balance': 0,
                'balances': {},
                'positions': []
            }

            # Process balances (this should always work)
            total_balance = 0
            for asset in balance:
                asset_balance = float(asset['balance'])
                if asset_balance > 0:
                    portfolio['balances'][asset['asset']] = asset_balance
                    total_balance += asset_balance  # Approximate total

            portfolio['total_wallet_balance'] = total_balance

            # Try to get more detailed info if available
            if account:
                # Check what keys are actually available and use them safely
                for key in ['totalWalletBalance', 'totalMarginBalance', 'totalInitialMargin']:
                    if key in account:
                        portfolio['total_wallet_balance'] = float(account[key])
                        break

                for key in ['totalUnrealizedPnL', 'totalUnrealizedProfit', 'totalCrossUnPnl']:
                    if key in account:
                        portfolio['total_unrealized_pnl'] = float(account[key])
                        break

                for key in ['availableBalance', 'maxWithdrawAmount']:
                    if key in account:
                        portfolio['available_balance'] = float(account[key])
                        break

            # Process positions if available
            for position in positions:
                position_amt = float(position.get('positionAmt', 0))
                if position_amt != 0:
                    portfolio['positions'].append({
                        'symbol': position.get('symbol', 'N/A'),
                        'size': position_amt,
                        'entry_price': float(position.get('entryPrice', 0)),
                        'mark_price': float(position.get('markPrice', 0)),
                        'pnl': float(position.get('unRealizedPnL', 0)),
                        'percentage': float(position.get('percentage', 0))
                    })

            self.logger.info("Retrieved portfolio summary successfully")
            return portfolio

        except Exception as e:
            self.logger.error(f"Failed to get portfolio summary: {str(e)}")
            return None







if __name__ == '__main__':
    b = BasicBot()
    print(b.get_portfolio_summary())










